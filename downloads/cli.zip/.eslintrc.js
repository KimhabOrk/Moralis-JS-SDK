module.exports = {
  extends: ['@moralisweb3'],
  ignorePatterns: ['**/build/**/*'],
};
